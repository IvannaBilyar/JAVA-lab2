package lab2;

import Serialize.SerializeJSON;
import Serialize.SerializeTXT;
import Serialize.SerializeXML;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lab2.Teachers;

import java.io.File;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) throws JsonProcessingException {

        Teachers t1 = new Teachers.Builder()
                .setName("Olha")
                .setSurname("Ivanko")
                .setBirthday(LocalDate.of(1994, 9, 12))
                .setLanguage("Chinese")
                .setDateOfEmployment(LocalDate.of(2017,12,5)).build();

        SerializeTXT serializeTxt = new SerializeTXT();
        SerializeJSON serializeJson = new SerializeJSON();
        SerializeXML serializeXml = new SerializeXML();
        File fTxt = new File("teacher.txt");
        File fJson = new File("teacher.json");
        File fXml = new File("teacher.xml");
        try {
            serializeTxt.serialize(t1, new File(String.valueOf(fTxt)));
            serializeJson.serialize(t1, new File(String.valueOf(fJson)));
            serializeXml.serialize(t1, new File(String.valueOf(fXml)));
        } catch (Exception e) {
            System.out.println(e.getStackTrace());
        }

        Teachers teacherTxt = new Teachers();
        Teachers teacherJson = new Teachers();
        Teachers teacherXml = new Teachers();

        try {
            teacherTxt = (Teachers) serializeTxt.deserialize(fTxt);
            teacherJson = (Teachers) serializeJson.deserialize(fJson);
            teacherXml = (Teachers) serializeXml.deserialize(fXml);
        } catch (Exception e) {
            System.out.println(e.getStackTrace());
        }

        System.out.println(teacherTxt);
        System.out.println(teacherJson);
        System.out.println(teacherXml);



    }
}




