package lab2;


import java.time.LocalDate;
import java.util.Objects;


public class Students extends Person {

    private String phoneNumber;
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Class "Builder" with fields: student
     * @author User
     * @version 1.0
     */
    public static class Builder{
        private Students student;
        private String phoneNumber;

        public Builder(){
            student = new Students();
        }

        /**
         * Setter phoneNumber designation
         * @param phoneNumber - name of student
         * @return returns current object
         */
        public Builder setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        /**
         * Setter name designation
         * @param name - name of student
         * @return returns current object
         */
        public Builder setName(String name){
            student.name = name;
            return this;
        }
        /**
         * Setter  surname designation
         * @param surname - surname of student
         * @return returns current object
         */
        public Builder setSurname(String surname){
            student.surname = surname;
            return this;
        }
        /**
         * Setter  age designation
         * @param birthday - age of student
         * @return returns current object
         */
        public Builder setBirthday(LocalDate birthday){
            student.birthday = birthday;
            return this;
        }

        /**
         * Setter of creating an object of class "Students"
         * @return returns new object of class "Students"
         */

        public Students build(){
            return student;
        }
    }


    /**
     *  Overridden function of obtaining a string representation of
     *  an instance of a class "Students"
     *  @return returns the string representation
     */
    @Override
    public String toString() {
        return "Students: " +
                "Name = " + name + "; " +
                "Surname = " + surname + "; " +
                "Birthday = " + birthday + ";" +
                "PhoneNumber = " + phoneNumber;
    }


    /**
     * Overridden function of comparison an instance of
     * the class "Students" and an instance of the class "Object"
     * @return returns the boolean value of the comparison
     */
    @Override
    public boolean equals(Object obj){
        if (this == obj){
            return true;
        }
        if(obj == null || this.getClass() != obj.getClass()){
            return false;
        }
        Students s = (Students) obj;
        return name.equals(s.name) && surname.equals(s.surname) && birthday == s.birthday;

    }

    /**
     * Overridden function of obtaining the hash code
     * @return returns the numeric value of the hash code
     */
    @Override
    public int hashCode(){
        return Objects.hash(name, surname, birthday);
    }

}
