package Serialize;

import lab2.Teachers;

import java.io.*;
import java.time.LocalDate;


public class SerializeTXT {
    public void serialize(Teachers obj, File file) throws IOException {
        try(FileWriter fw = new FileWriter(file)){
            String str = "Name = " + obj.getName() + ", " +
                    "Surname = " + obj.getSurname() + ", " +
                    "DateOfBirthday = " + obj.getBirthday() + ", " +
                    "Language = " + obj.getLanguage() + ", " +
                    "DateOfEmployment = " + obj.getDateOfEmployment();
            fw.write(str);
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public Teachers deserialize(File file) throws IOException {
        try (BufferedReader fr = new BufferedReader(new FileReader(file))) {
            String[] fields = fr.readLine().split(", ");
            Teachers.Builder a = new Teachers.Builder();
            a.setName(fields[0].split(" ")[2]);
            a.setSurname(fields[1].split(" ")[2]);
            a.setBirthday(LocalDate.ofEpochDay(Integer.parseInt(fields[2].split(" ")[2])));
            a.setLanguage(fields[3].split(" ")[2]);
            a.setDateOfEmployment(LocalDate.ofEpochDay(Integer.parseInt(fields[2].split(" ")[2])));
            return a.build();
        }
        catch (IOException e) {
            throw new RuntimeException("File is empty");
        }
    }
}