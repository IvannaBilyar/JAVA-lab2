import Serialize.SerializeJSON;
import lab2.Teachers;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SerializeTest {
    Teachers t1 = new Teachers.Builder()
            .setName("Olha")
            .setSurname("Ivanko")
            .setBirthday(LocalDate.of(1994, 9, 12))
            .setLanguage("Chinese")
            .setDateOfEmployment(LocalDate.of(2017,12,5)).build();



    @Test
    public void testJsonSerialization() throws IOException {
        SerializeJSON serializeJson = new SerializeJSON();

        serializeJson.serialize(t1, new File("teacher.json"));
        Teachers deserializedTeacher = (Teachers) serializeJson.deserialize(new File("teacher.txt"));
        assertEquals(t1, deserializedTeacher);

    }
}
